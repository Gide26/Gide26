# BCM Medical Centre — on the premises

The set in place, drawn to scale from the same print files that go to the printer.

| File | What it is |
| --- | --- |
| `lookbook/M-01-premises-day.png` | The front by day — three black doorways, three banners, the sign post |
| `lookbook/M-02-premises-night.png` | The front at night, with the eaves downlights |
| `lookbook/M-1N-door-N-black.png` | Each doorway close up, banner above it |
| `lookbook/M-04-setout.png` | Set-out drawing, all dimensions in mm |
| `BCM-Premises.pdf` | Six pages — the same, for the meeting |
| `in-place.html` | One self-contained page, every image embedded — opens anywhere |

## What is drawn

- Doorways: 2220 mm wide overall, 1980 mm door head, two leaves, black frame and
  black leaves, eight panes of film each — 900 mm high, 500 mm outer, 400 mm at the
  meeting stile, exactly as scheduled on the door pages.
- Banners: B-1 (3.8 m) over door 1, B-2 (3.4 m) over door 2, and B-3 — 16 ft × 49 in
  (4.88 × 1.24 m) since 2026-11-07 — on the long run above door 4; it is more than twice a
  doorway wide, so it no longer fits over a single door and door 3's wall is left clear.
  Underside 2560 mm above the paving, 580 mm clear of the door head.
- Sign post at the kerb: 1168.4 × 558.8 mm panel (46 × 22 in), centre 1500 mm above
  finished ground, on two 76 mm posts at 520 mm centres — the support is a proposal
  for the signwriter to confirm. The face is drawn as it is built: the red-on-white
  lit face for the lighting board, not the old navy one.

Door centres — 4.2 m and 3.4 m — and the 2560 mm banner height are proposals chosen so
the banners clear each other. Confirm them, and the wall height above each door, before
anything is fixed.

Rebuild: `cd source && python3 bcm_premises.py`
